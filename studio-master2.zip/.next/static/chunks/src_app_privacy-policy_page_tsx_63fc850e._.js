(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_privacy-policy_page_tsx_63fc850e._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_privacy-policy_page_tsx_63fc850e._.js",
  "chunks": [
    "static/chunks/_5a082253._.js"
  ],
  "source": "dynamic"
});

(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_cars_[id]_page_tsx_0124b1f9._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_cars_[id]_page_tsx_0124b1f9._.js",
  "chunks": [
    "static/chunks/src_066d9a77._.js",
    "static/chunks/node_modules_2394166e._.js"
  ],
  "source": "dynamic"
});

(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_about_page_tsx_63fc850e._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_about_page_tsx_63fc850e._.js",
  "chunks": [
    "static/chunks/_5bac0880._.js"
  ],
  "source": "dynamic"
});

(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_tsx_f0e4c1a2._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_tsx_f0e4c1a2._.js",
  "chunks": [
    "static/chunks/[root of the server]__b07dbc43._.css",
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_9225fee4._.js",
    "static/chunks/src_c0879e9a._.js",
    "static/chunks/d9ef2_@firebase_auth_dist_esm2017_98d2eb47._.js",
    "static/chunks/node_modules_framer-motion_dist_es_92139a2a._.js",
    "static/chunks/node_modules_38a9a856._.js"
  ],
  "source": "dynamic"
});

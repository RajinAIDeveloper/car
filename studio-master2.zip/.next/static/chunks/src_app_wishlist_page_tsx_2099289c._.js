(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_wishlist_page_tsx_2099289c._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_wishlist_page_tsx_2099289c._.js",
  "chunks": [
    "static/chunks/node_modules_10201934._.js",
    "static/chunks/src_components_eea24041._.js"
  ],
  "source": "dynamic"
});

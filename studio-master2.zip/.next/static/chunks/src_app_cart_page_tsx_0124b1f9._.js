(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_cart_page_tsx_0124b1f9._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_cart_page_tsx_0124b1f9._.js",
  "chunks": [
    "static/chunks/node_modules_6615e438._.js",
    "static/chunks/src_components_a54e7535._.js"
  ],
  "source": "dynamic"
});

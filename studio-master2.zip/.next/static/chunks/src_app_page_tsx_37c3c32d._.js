(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_37c3c32d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_37c3c32d._.js",
  "chunks": [
    "static/chunks/src_2c3e80b2._.js",
    "static/chunks/node_modules_17228edf._.js"
  ],
  "source": "dynamic"
});

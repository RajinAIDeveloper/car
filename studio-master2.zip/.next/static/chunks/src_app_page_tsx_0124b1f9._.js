(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_0124b1f9._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_0124b1f9._.js",
  "chunks": [
    "static/chunks/src_2c3e80b2._.js",
    "static/chunks/node_modules_71683d6e._.js"
  ],
  "source": "dynamic"
});

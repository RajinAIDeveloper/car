(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_cars_[id]_page_tsx_2099289c._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_cars_[id]_page_tsx_2099289c._.js",
  "chunks": [
    "static/chunks/src_dcca7978._.js",
    "static/chunks/node_modules_2394166e._.js"
  ],
  "source": "dynamic"
});

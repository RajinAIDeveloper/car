module.exports = {

"[project]/.next-internal/server/app/cars/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
"[project]/src/app/favicon.ico.mjs { IMAGE => \"[project]/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/favicon.ico.mjs { IMAGE => \"[project]/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)"));
}}),
"[project]/src/app/layout.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/layout.tsx [app-rsc] (ecmascript)"));
}}),
"[project]/src/data/cars.ts [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "addReviewToCar": (()=>addReviewToCar),
    "cars": (()=>cars),
    "getCarById": (()=>getCarById)
});
const initialReviews = [
    {
        id: 'r1',
        carId: '1',
        userName: 'Alice',
        rating: 5,
        comment: 'Absolutely love this car! Smooth ride and great features.',
        createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString()
    },
    {
        id: 'r2',
        carId: '1',
        userName: 'Bob',
        rating: 4,
        comment: 'Very reliable and fuel-efficient. Good value for money.',
        createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString()
    },
    {
        id: 'r3',
        carId: '2',
        userName: 'Charlie',
        rating: 4,
        comment: 'Powerful engine and stylish design. A bit pricey though.',
        createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString()
    },
    {
        id: 'r4',
        carId: '3',
        userName: 'Diana',
        rating: 5,
        comment: 'Perfect family SUV. Lots of space and safety features.',
        createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString()
    }
];
let cars = [
    {
        id: '1',
        make: 'Toyota',
        model: 'Camry',
        year: 2023,
        price: 104595,
        description: 'A reliable and comfortable mid-size sedan, perfect for families and daily commutes. Known for its fuel efficiency and smooth ride.',
        imageUrls: [
            '/camry.jpeg',
            '/camry2.jpeg',
            '/camry3.jpg'
        ],
        dataAiHint: 'sedan silver',
        features: [
            'Fuel Efficient',
            'Spacious Interior',
            'Advanced Safety Features',
            'Smooth Ride',
            'Apple CarPlay'
        ],
        averageRating: 4.7,
        reviewsCount: 120,
        reviews: initialReviews.filter((r)=>r.carId === '1')
    },
    {
        id: '2',
        make: 'Honda',
        model: 'Civic',
        year: 2023,
        price: 91750,
        description: 'A compact car that offers a sporty driving experience, excellent fuel economy, and a refined interior.',
        imageUrls: [
            '/civic.jpeg'
        ],
        dataAiHint: 'sedan red',
        features: [
            'Sporty Handling',
            'Fuel Efficient',
            'Modern Infotainment',
            'Reliable'
        ],
        averageRating: 4.6,
        reviewsCount: 95,
        reviews: initialReviews.filter((r)=>r.carId === '2')
    },
    {
        id: '3',
        make: 'Ford',
        model: 'Explorer',
        year: 2024,
        price: 154140,
        description: 'A versatile and spacious SUV with three rows of seating, powerful engine options, and a comfortable ride.',
        imageUrls: [
            '/explorer.jpeg'
        ],
        dataAiHint: 'suv blue',
        features: [
            'Three-Row Seating',
            'Powerful Engine',
            'Ample Cargo Space',
            'Towing Capacity'
        ],
        averageRating: 4.4,
        reviewsCount: 75,
        reviews: initialReviews.filter((r)=>r.carId === '3')
    },
    {
        id: '4',
        make: 'Tesla',
        model: 'Model 3',
        year: 2023,
        price: 146800,
        description: 'An all-electric sedan with impressive range, cutting-edge technology, and exhilarating performance.',
        imageUrls: [
            '/model3.jpeg'
        ],
        dataAiHint: 'electric white',
        features: [
            'Electric Vehicle',
            'Long Range',
            'Autopilot Capable',
            'Minimalist Interior',
            'Large Touchscreen'
        ],
        averageRating: 4.8,
        reviewsCount: 150,
        reviews: []
    },
    {
        id: '5',
        make: 'BMW',
        model: 'X5',
        year: 2024,
        price: 238550,
        description: 'A luxury mid-size SUV that combines performance, comfort, and advanced technology in a stylish package.',
        imageUrls: [
            '/bmwx5.jpeg'
        ],
        dataAiHint: 'suv black',
        features: [
            'Luxury Interior',
            'Performance Engine Options',
            'Advanced Driver Assists',
            'Panoramic Sunroof'
        ],
        averageRating: 4.7,
        reviewsCount: 60,
        reviews: []
    },
    {
        id: '6',
        make: 'Audi',
        model: 'A4',
        year: 2023,
        price: 157810,
        description: 'A compact luxury sedan offering a refined driving experience, high-quality interior, and advanced technology.',
        imageUrls: [
            '/audia4.jpg'
        ],
        dataAiHint: 'sedan gray',
        features: [
            'Quattro All-Wheel Drive',
            'Virtual Cockpit',
            'Premium Sound System',
            'Leather Upholstery'
        ],
        averageRating: 4.5,
        reviewsCount: 88,
        reviews: []
    },
    {
        id: '7',
        make: 'Jeep',
        model: 'Wrangler',
        year: 2024,
        price: 139460,
        description: 'The iconic off-road SUV, built for adventure with rugged capabilities and open-air freedom.',
        imageUrls: [
            '/wrangler.jpeg'
        ],
        dataAiHint: 'suv green',
        features: [
            'Off-Road Prowess',
            'Removable Top/Doors',
            '4x4 System',
            'Durable Build'
        ],
        averageRating: 4.3,
        reviewsCount: 110,
        reviews: []
    },
    {
        id: '8',
        make: 'Subaru',
        model: 'Outback',
        year: 2023,
        price: 117440,
        description: 'A versatile wagon/SUV crossover known for its standard all-wheel drive, safety features, and practicality.',
        imageUrls: [
            '/outback.webp'
        ],
        dataAiHint: 'wagon brown',
        features: [
            'Symmetrical AWD',
            'EyeSight Driver Assist',
            'Spacious Cargo Area',
            'Roof Rails'
        ],
        averageRating: 4.6,
        reviewsCount: 92,
        reviews: []
    }
];
const getCarById = (id)=>{
    return cars.find((car)=>car.id === id);
};
const addReviewToCar = (carId, review)=>{
    const carIndex = cars.findIndex((c)=>c.id === carId);
    if (carIndex !== -1) {
        const car = cars[carIndex];
        const updatedReviews = [
            ...car.reviews || [],
            review
        ];
        const totalRating = updatedReviews.reduce((sum, r)=>sum + r.rating, 0);
        car.reviews = updatedReviews;
        car.reviewsCount = updatedReviews.length;
        car.averageRating = parseFloat((totalRating / updatedReviews.length).toFixed(1));
        return car;
    }
    return undefined;
};
}}),
"[project]/src/components/cars/CarDetailClient.tsx (client reference/proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "CarDetailClient": (()=>CarDetailClient)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const CarDetailClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call CarDetailClient() from the server but CarDetailClient is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/src/components/cars/CarDetailClient.tsx <module evaluation>", "CarDetailClient");
}}),
"[project]/src/components/cars/CarDetailClient.tsx (client reference/proxy)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "CarDetailClient": (()=>CarDetailClient)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const CarDetailClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call CarDetailClient() from the server but CarDetailClient is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/src/components/cars/CarDetailClient.tsx", "CarDetailClient");
}}),
"[project]/src/components/cars/CarDetailClient.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$cars$2f$CarDetailClient$2e$tsx__$28$client__reference$2f$proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/src/components/cars/CarDetailClient.tsx (client reference/proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$cars$2f$CarDetailClient$2e$tsx__$28$client__reference$2f$proxy$29$__ = __turbopack_context__.i("[project]/src/components/cars/CarDetailClient.tsx (client reference/proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$cars$2f$CarDetailClient$2e$tsx__$28$client__reference$2f$proxy$29$__);
}}),
"[project]/src/app/cars/[id]/page.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
// src/app/cars/[id]/page.tsx
__turbopack_context__.s({
    "default": (()=>CarDetailPage),
    "generateMetadata": (()=>generateMetadata)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$cars$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/data/cars.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$cars$2f$CarDetailClient$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/cars/CarDetailClient.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$api$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/next/dist/api/navigation.react-server.js [app-rsc] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/components/navigation.react-server.js [app-rsc] (ecmascript)");
;
;
;
;
async function generateMetadata({ params }, parent) {
    const car = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$cars$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getCarById"])(params.id);
    if (!car) {
        return {
            title: 'Car Not Found - DriveDeals'
        };
    }
    const primaryImageUrl = car.imageUrls && car.imageUrls.length > 0 ? car.imageUrls[0] : undefined;
    return {
        title: `${car.make} ${car.model} (${car.year}) - DriveDeals`,
        description: car.description,
        openGraph: {
            title: `${car.make} ${car.model} - DriveDeals`,
            description: car.description,
            images: primaryImageUrl ? [
                {
                    url: primaryImageUrl,
                    width: 600,
                    height: 400,
                    alt: `${car.make} ${car.model}`
                }
            ] : []
        }
    };
}
function CarDetailPage({ params }) {
    const car = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$cars$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getCarById"])(params.id);
    if (!car) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["notFound"])();
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$cars$2f$CarDetailClient$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["CarDetailClient"], {
        car: car
    }, void 0, false, {
        fileName: "[project]/src/app/cars/[id]/page.tsx",
        lineNumber: 51,
        columnNumber: 10
    }, this);
}
}}),
"[project]/src/app/cars/[id]/page.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/cars/[id]/page.tsx [app-rsc] (ecmascript)"));
}}),

};

//# sourceMappingURL=_bfc453ec._.js.map